package pub.ants.rpn;

import pub.ants.utils.DataTransUtil;
import pub.ants.utils.StackUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Stack;

/**
 * RPN计算器包含：
 *   1. 操作数：double类型数据
 *   2. 操作符：一元运算符号(sqrt)和二元运算符(+、-、*、/)
 *   3. 其他操作符： clean、undo
 *   4. 违法字符
 *
 *   思路：
 *   1. 设计两个栈，分别存储操作数和日志，操作数栈执行操作，日志栈用来保存本次操作数据中栈的所有值
 *   2. 判断是否是数值类型，不是数值类型就是操作数(或违法字符)
 *   3. 执行操作时，按照顺序进行计算，首先把执行后的操作数入栈，再把操作栈数据入到日志栈中
 *   4. 执行undo clean 操作时，清空操作栈，在把日志栈中的数据恢复到操作数栈
 *   5. 操作完成后，打印操作栈数据(保留2位小数)
 */
public class RPNCalculator {


    //RPN使用stack变量定义
    private Stack<Double> stack = new Stack();//记录栈数据操作
    private Stack<List<Double>> stackLog = new Stack();//记录操作日志，用来undo操作


    //校验输入字符串的合法性以及进行计算

    private void calCheckAndCal(String rpnStr) throws Exception {
        String[] rpnArr = rpnStr.split(StackUtils.REGEX); // 切分字符串
        for(int i=0,j= rpnArr.length;i<j;i++){//遍历数组
            String dealData = rpnArr[i].trim();//获得操作数或操作值
            Double number;//操作数
            if(null!=(number=DataTransUtil.strToDouble(dealData))){//通过将字符串转数字，如果成功值不为null，这样可以划分操作数和操作符
                stack.push(number);//操作数入栈
                stackLog.push(StackUtils.getStack(stack)); //日志栈记录操作数栈的数据变化
            }else{
                //一元操作符
                if(StackUtils.SQRT.equals(dealData)){
                    if(stack.size()>0){//stack中存在数据，可进行开方操作
                        RPNOperator.sqrtOpeator(stack,stackLog);
                    }else{
                        System.out.printf("operator%s(position:%d):insufficient parameters ",dealData,(2 * i - 1));
                        break;
                    }
                }else if(StackUtils.TWOOPER.contains(dealData)){
                    if(stack.size()>1){//stack中存在2个及以上数据，可进行二元操作
                        RPNOperator.fourArithmetic(stack,stackLog,dealData);
                    }else{
                        System.out.printf("operator%s(position:%d):insufficient parameters ",dealData,(2 * i + 1));
                        break;
                    }
                }else if(StackUtils.CLEAN.equals(dealData)||StackUtils.UNDO.equals(dealData)){
                    RPNOperator.undoAndClean(stack,stackLog,dealData);
                }else{
                    throw new Exception("您本次输入不合法："+rpnStr);
                }
            }
        }
        StackUtils.showStack(stack);
    }

    //获得从控制台输入的字符串
    private String getInputString(){
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in ));
        String read = null;
        try {
            read = br.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return read;
    }
    public static void main(String[] args) {
        RPNCalculator rpnCal = new RPNCalculator();
        try {
            //多次计算,控制台输入数据，按回车，结束本次操作
            while (true) {
                String rpnStr = rpnCal.getInputString();
                rpnCal.calCheckAndCal(rpnStr);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
