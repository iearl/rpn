package pub.ants.rpn;

import pub.ants.utils.StackUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

/**
 * 数据操作处理
 * 用途：处理操作，数据出栈入栈
 */
public class RPNOperator {

    //undo clean 操作
    public static void undoAndClean(Stack<Double> stack, Stack<List<Double>> stackLog, String opt)  {
        while (!stack.empty()) { // undo、clean操作的首先需要把栈清空，恢复到日志记录的相关数据
            stack.pop();
        }
        if(StackUtils.UNDO.equals(opt)) {
            if (!stackLog.empty()) { // 因为日志栈是记录每一次操作，所以将这步操作后退
                stackLog.pop();
                if (!stackLog.empty()) {// 取得日志栈栈顶数据
                    List<Double> list1 = stackLog.peek(); // peek()方法取栈顶数据，不会将数据弹出栈
                    for (int i = 0,j=list1.size(); i < j; i++) {
                        if (list1.get(i) != null) {
                            stack.push(list1.get(i));
                        }
                    }
                }
            }
        }else if(StackUtils.CLEAN.equals(opt)){
            //clean操作，把null入栈
            stackLog.push(new ArrayList<Double>(){{add(null);}});
        }
    }
    //加减乘除四则运算
    public static void fourArithmetic(Stack<Double> stack, Stack<List<Double>> stackLog, String opt) throws Exception {
        double num2 = stack.pop();//取得第二个操作数
        double num1 = stack.pop();//取得第一个操作数
        switch (opt){
            case "+":stack.push(num1 + num2); // 计算并将结果入栈
                break;
            case "-":stack.push(num1 - num2); // 计算并将结果入栈
                break;
            case "*":stack.push(num1 * num2); // 计算并将结果入栈
                break;
            case "/":{
                if (num2==0)
                    throw new Exception("除数不能为0");
                stack.push(num1 / num2); // 计算并将结果入栈
                break;
            }
            default:
                throw new Exception("操作符不正确");
        }
        stackLog.push(StackUtils.getStack(stack));//将操作的数记录到日志栈中
    }
    //开方操作
    public static void sqrtOpeator(Stack<Double> stack, Stack<List<Double>> stackLog) throws Exception {
        double num = stack.pop();
        if (num<0)
            throw new Exception("开方值需要不小于0");
        stack.push(Math.sqrt(num));
        stackLog.push(StackUtils.getStack(stack));
    }
}
