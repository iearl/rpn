package pub.ants.utils;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

/**
 * 栈中操作类，定义枚举及栈的相关操作
 */
public class StackUtils {
    //常量定义
    public static final String REGEX = " ";//定义分割字符串
    public static final String CLEAN = "clean";//运算符，删除操作数栈中信息
    public static final String UNDO = "undo";//撤销上一步操作
    public static final String SQRT = "sqrt";//一元运算符开方
    public static final List<String> TWOOPER = new ArrayList<String>(){{add("+");add("-");add("*");add("/");}};//四则运算

    //日志入栈，每次有数据产生就将整个栈中的输入入到日志栈中，方便undo操作
    public static List<Double> getStack(Stack<Double> stack) {
        List<Double> getStk = new ArrayList<>();
        for (Double x : stack) {
            getStk.add(x);
        }
        return getStk;
    }
    //显示栈中所有元素，保留2位小数
    public static void showStack(Stack<Double> stk) {
        if (stk.size() != 0) {//栈不为空
            System.out.print("stack:");
            for (Double x : stk) {
                System.out.print(new DecimalFormat("##########.##").format(x) + " ");
            }
        } else {//栈空
            System.out.println("stack:");
        }
        System.out.println();
    }
}
