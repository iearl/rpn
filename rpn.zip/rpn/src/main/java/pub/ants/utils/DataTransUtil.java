package pub.ants.utils;

import java.util.regex.Pattern;

/**
 * 工具类，用来字符串转数值
 */
public class DataTransUtil {

    //验证数值正则表达式
    public static final String INPUT="^(\\-|\\+)?\\d+(\\.\\d+)?$";

    //正则校验是否是数值类型
    private static  boolean isNumber(String str){
        Pattern pattern = Pattern.compile(INPUT);
        return pattern.matcher(str).matches();
    }

    //将字符串转为日期
    public static Double strToDouble(String src) {
        return isNumber(src)==true? Double.valueOf(src):null;
    }
}
